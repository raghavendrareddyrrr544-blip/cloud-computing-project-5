const express = require("express");

const app = express();

app.use(express.static(__dirname));

app.get("/api/attendance",(req,res)=>{

    res.json({
        message:
        "Attendance stored successfully in Cloud Database"
    });

});

app.listen(3000,()=>{

    console.log(
    "Server Running at http://localhost:3000"
    );

});