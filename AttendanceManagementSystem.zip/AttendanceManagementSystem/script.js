let count = 0;

function login(){

    let teacher = document.getElementById("teacher").value;

    if(teacher === ""){
        alert("Enter Teacher Name");
        return;
    }

    document.getElementById("loginMsg").innerHTML =
    "Welcome " + teacher;
}

async function addAttendance(){

    let student =
    document.getElementById("studentName").value;

    let status =
    document.getElementById("status").value;

    if(student === ""){
        alert("Enter Student Name");
        return;
    }

    const response =
    await fetch("/api/attendance");

    const data =
    await response.json();

    let date =
    new Date().toLocaleString();

    let card =
    document.createElement("div");

    card.className = "card";

    card.innerHTML =
    `
    <h3>${student}</h3>
    <p><b>Status:</b> ${status}</p>
    <p><b>Date:</b> ${date}</p>
    <p>${data.message}</p>

    <button onclick="deleteRecord(this)">
    Delete
    </button>
    `;

    document.getElementById("attendanceList")
    .appendChild(card);

    count++;

    document.getElementById("count")
    .innerHTML = count;

    document.getElementById("studentName")
    .value = "";
}

function deleteRecord(btn){

    btn.parentElement.remove();

    count--;

    if(count < 0){
        count = 0;
    }

    document.getElementById("count")
    .innerHTML = count;
}